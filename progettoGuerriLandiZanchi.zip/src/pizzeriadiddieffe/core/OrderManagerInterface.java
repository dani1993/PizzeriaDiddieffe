package pizzeriadiddieffe.core;

public interface OrderManagerInterface {
	public Order checkOrder(String id);
}