package pizzeriadiddieffe.core.focaccia;

import pizzeriadiddieffe.core.Item;

public abstract class Focaccia implements Item{
	public abstract String getInfo();	
	public abstract double getPrice();
}