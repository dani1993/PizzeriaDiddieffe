package pizzeriadiddieffe.core;

public interface SoundPlayerInterface {
	public void setSound(String soundName);
	public void playSound() throws Exception;
}