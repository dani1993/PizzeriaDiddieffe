package pizzeriadiddieffe.gui.componentclasses;

import java.awt.Component;
import java.awt.Container;
import java.util.List;

public interface ComponentGetterInterface {
	public List<Component> getComponents(Container currentComponent);
}