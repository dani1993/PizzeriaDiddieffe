package pizzeriadiddieffe.gui.formattedelements;

public interface HtmlFormatterInterface {
	public String getBullet() ;
	public String getComma() ;	
	public String getTabSpace();	
	public String getEndItalic();	
	public String getNewLine() ;	
	public String getStartBold();	
	public String getEndBold();	
	public String getPrice();	
	public String getHighligh() ;
	public String getEndhighligh();
}