package pizzeriadiddieffe.gui.jpanel.jpanelwithbackground;

import javax.swing.JFrame;
import javax.swing.JPanel;

public interface JPanelWithImageInterface {
	public void setVisiblePanel(JPanel visiblePanel, JFrame frame);
	public JFrame getFrame();
}