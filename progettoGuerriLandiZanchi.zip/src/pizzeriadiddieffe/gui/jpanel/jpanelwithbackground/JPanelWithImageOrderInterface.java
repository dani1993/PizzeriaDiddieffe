package pizzeriadiddieffe.gui.jpanel.jpanelwithbackground;

public interface JPanelWithImageOrderInterface {
	public void setTableId (String id);
}