package pizzeriadiddieffe.gui;

import pizzeriadiddieffe.core.Order;

public interface OrderViewerInterface {
	public void setOrder(Order myOrder);
}